Data1 <-read.csv('./DMAs3/A3data2.csv')

# Cluster the data (k=3)
set.seed(2)
km.out=kmeans(Data1[,1:2],3,nstart=20)
plot(Data1[,1:2], col=(km.out$cluster+1), main="K-Means Clustering Results with K=3", xlab="", ylab="", pch=20, cex=2)

## Hierarchically clustering the data using complete linkage method
hc.complete=hclust(dist(Data1[,1:2]), method="complete")

# Cut the trees to define clusters
cut_tree <-cutree(hc.complete, 3)

# Plot the dendrogram
plot(hc.complete,main="Complete Linkage", xlab="", sub="", cex=.9)

# Plot the clustering with 3 clusters
plot(Data1[,1:2],col = cut_tree, main="Hierarchical Clustering Results with 3 clusters", xlab="", ylab="", pch=20, cex=2)

## Hierarchically clustering the data using sigle linkage method
hc.single=hclust(dist(Data1[,1:2]), method="single")
plot(hc.single,main="Single Linkage", xlab="", sub="", cex=.9)

cut_tree1 <-cutree(hc.single, 3)
plot(Data1[,1:2],col = cut_tree1, main="Hierarchical Single Linkage Clustering with 3 clusters", xlab="", ylab="", pch=20, cex=2)

# Cluster the data (k=3, multiple restarts)
set.seed(3)
km.out=kmeans(Data1[,1:2],3,nstart=1)
km.out$tot.withinss
km.out=kmeans(Data1[,1:2],3,nstart=100)
km.out$tot.withinss
km.out=kmeans(Data1[,1:2],3,nstart=100)
km.out$tot.withinss
plot(Data1[,1:2], col=(km.out$cluster+1), main="K-Means Clustering Results with K=3", xlab="", ylab="", pch=20, cex=2)

# Rescaling the data
Data2 <- scale(Data1, center=TRUE, scale=TRUE)

# Cluster the data (k=3
set.seed(2)
km.out=kmeans(Data2[,1:2],3,nstart=20)
plot(Data2[,1:2], col=(km.out$cluster+1), main="K-Means Clustering Results with K=3", xlab="", ylab="", pch=20, cex=2)

## Hierarchically clustering the data using complete linkage method
hc.complete1=hclust(dist(Data2[,1:2]), method="complete")

# Plot the dendrogram
plot(hc.complete1,main="Complete Linkage", xlab="", sub="", cex=.9)

# Cut the trees to define clusters
cut_tree3 <-cutree(hc.complete1, 3)
# Plot the clustering with 3 clusters
plot(Data2[,1:2],col = cut_tree3, main="Hierarchical Clustering Results with 3 clusters", xlab="", ylab="", pch=20, cex=2)

## Hierarchically clustering the data using sigle linkage method
hc.single1=hclust(dist(Data2[,1:2]), method="single")
plot(hc.single1,main="Single Linkage", xlab="", sub="", cex=.9)

cut_tree4 <-cutree(hc.single1, 3)
plot(Data2[,1:2],col = cut_tree4, main="Hierarchical Single Linkage Clustering with 3 clusters", xlab="", ylab="", pch=20, cex=2)
