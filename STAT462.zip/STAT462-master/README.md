# Data Mining
Assignments done as part of the course curriculum.
This is one of the area that I look forward to learn more.

Assignment1 is a 1. discussion on flexible and less flexible regression methods, 2. Density plot of a binary classification problem with their prior probabilities 3. Fitting knn regression model on the data. Best model withvalue of k=30 MSE=17.95

Assignment2 1. Fitted a logistic regression model to predict the probability of a bank note being forged. Prediction accuracy = 88.6%, 2. Fitted the same data with LDA and QDA models. These models improved the accuracy rate, 3. Comparison of test errors.

Assignment3 1. Applied k-means clustering and hierarchial clustering on the data with and without rescaling. dataset:A3data2 2. Support vector classifier is fitted to predict the probability of a bank note being forged. 2. Fitted the data with Support Vector Machine using Radial kernel and compared the results. Model accuracy = 91.26%
