## Support vector machines

install.packages("e1071")
library(e1071)
Train = read.csv('./DMAs2/BankTrain.csv')
Train$y=as.factor(Train$y) 
plot(Train$x1, Train$x3, col=Train$y, xlab="x1", ylab="x3",pch=20, cex=2)
legend("topright",legend = c("Forged", "Genuine"),col = c("red","black"), pch=20)

## Support vector classifier
set.seed(1)
Train1 = Train[,c(1,3,5)]
Train1$y = as.factor(Train1$y)
tune.out = tune(svm, y~x1+x3, data=Train1, kernel="linear", ranges=list(cost=c(0.001,0.01,0.1,1,10,100)))
summary(tune.out)

# Plot the best classifier using the best cost value
best_model = tune.out$best.model
plot(best_model, Train1)

# Confusion matrix for the testing data
Test = read.csv("./DMAs2/BankTest.csv", header=TRUE, na.strings="?")
Test$y = as.factor(Test$y)
Test1 = Test[,c(1,3,5)]
ypred = predict(best_model, Test)
table(predict=ypred, truth=Test$y)
mean(ypred==Test$y)  # Accuracy rate

# Support vector machine
tune.out1=tune(svm, y~x1+x3, data=Train, kernel="radial", ranges=list(cost=c(0.01,0.1,1,10,100),gamma=c(0.5,1,2,3,4)))
summary(tune.out1)

# Plot the best SVM using the best parameters
best_model1 = tune.out1$best.model
plot(best_model1, Train1)

# Confusion matrix for the testing data
ypred1 = predict(best_model1, Test)
table(predict=ypred1, truth=Test$y)
mean(ypred1==Test$y)  # Accuracy rate
