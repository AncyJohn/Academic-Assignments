# Data Wrangling for Data Science
These are the assignments done as part of the course curriculum.

Analytical tools: Ubuntu, Jupyter lab
Programming languages: R, Julia

For the assignment1 I have cleaned up the messy data, merged the datasets and produced the visual plots.

For the assignment2 we scrapped the data from the web, wrangled it, automated it and then produced some visual plots. Also we explored with certaine web services that offer data through APIs that can be converted into a dataframe.
