# Texts, Discourses and Data
These are the Lab exercises and assignments done as part of the course curriculum.

Lab exercise 1 is all about concordance analysis for finding patterns. The Clinton-Trump Corpus (Retrieved from http://www.thegrammarlab.com/?nor-portfolio=corpus-of-presidential-speeches-cops-and-a-clintontrump-corpus) consists of speeches by Hillary Clinton and Donald Trump at events during the 2016 US presidential election campaign. The speeches for each speaker are stored in two separate directories. Toolkit used for concordancing and analysis is Laurence Anthony's AntConc Software. We created a concordance of the word people to identify distinct pattern of usage.

Lab exercise 2a is on web scrapping using Python, BeautifulSoup and CSS selectors. We scrapped content from a site specifically setup for this task: Scraping Garden Party. Python libraries used are Requests and BeautifulSoup.

Lab exercise 2b demonstrates the functionality of regular expressions. Regular expressions are useful for data clean up, text normalization and feature extraction for analysis or modeling. Python libraries used are Requests and Re.

Lab exercise 2c is about detecting the named entities (Named Entity Recognition). Our named entity recogniser will attempt to detect the names of 'iwi'. Iwi are a fundamental social grouping in Māori society, both before and after British colonisation. Python libraries used are Spacy and Random. Data model is trained successfully with iwi as an entity label.

Lab exercise 3 is an assessment on the competence in applying Topic Modelling as a recommendation engine to Ted.com. Topic modelling is a statistical model to discover topics from a large collection of text. Topic model: Latent Drichlet Allocation (LDA) Software tool: Topic Modelling Tool (TMT). Top 3 recommendations for 2 specific videos are evaluated.

Corpus analysis on the representation of subcultures: fanfiction communities

Corpora analysis is a part of decision making to resolve many of the real-world issues.For this assessment I have explored the corpus of Harry Potter books communities.The fanfiction corpus that I have built up consists of 20 text files with almost 30,000 words. . I used Laurence Anthony’s antconc, which is an effective tool to identify patterns and keyword frequencies. To scrap the data I used web scraper tool from google chrome.

For the final assessment I build a Naive Bayes text classification model to detect fake/legit celebrity news, using Orange data mining tool. F1 score: 0.58 Precision: 0.62 Model accuracy: 60%
