# Big Data 
These are the assignments as part of the course curriculum.

Analytical tool: R studio
Programming language: R

Assignment 1 is a comaritative study on Ordinary Least Square Estimate(OLS) 1. By using Linear algebra calculations 2. By manual model fitting method in R 3. by using lm() function in R

Assignment 2 fits different regression models to predict the actual sales price. Dataset used is Residential-Building-Data-Set.xlsx. A comparitative study of stepwise selection, ridge,lasso models etc. are applied. Lasso regression model has the least RMSE value.

Assignment 3 is 1. demonstration of nodes/neurons and hidden layers in neural networks 2. application of filters on a convolutional neural network.

Final assessment is 1. on the understanding of different deep level machine learning concepts 2. Fitting a regression model to predict the percent of successful field goals based on 4 different predictors. The dataset ”mlr09” is about physical measurements and performances of 54 players in the NBA.
