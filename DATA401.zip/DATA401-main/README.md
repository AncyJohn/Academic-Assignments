# Statistics
These are the assignments done as part of the course curriculum. 

Assignment1: we considered 1. a study on area of the states in united states, with histograms and the summary statistics, 2. Total number of Tornados in the US states & territories using boxplot, 3. Exploration on a dataset by using visual methods.

Assignment2: 1. regression using excel. Problem: Family planning effect on fertility rate in 27 developing countries, 2. assessment on probability, random variables and the probability distribution models.

Assignment3: 1. assessment on hypothesis testing to generate confidence intervals, 2. study on cell phone radiation using descriptive statistics , usage of confidence interval on a survey: paid employment while studying at the university. 3. Hypothesis testing on the nutritional contents in packaged food and hypothesis test for university student's habit of watching TV genderwise. 

Project: Part 1 Critical appraising of a report. Report: Research and Development in New Zealand: 2018, Part 2 Analysis report on self sourced data. Title: Melbourne Housing Market. Analysis and regression done using excel spreadsheet.

