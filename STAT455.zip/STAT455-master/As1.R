# Required packages
library(sampling)
library(readxl)


# To load data
data <- read_excel("./DS/Ass1data.xlsx")
attach(data)

# 100 samples for Var1
SM1 <- vector(mode = "list", length = 100)
for(i in 1:100){
  s=srswor(250,length(Var1))
  rs <- as.vector(Var1[s==1])
  m <- mean(rs)
  SM1[[i]] <- m
}
  
# 100 samples for Var2
SM2 <- vector(mode = "list", length = 100)
for(i in 1:100){
  s=srswor(250,length(Var2))
  rs <- as.vector(Var2[s==1])
  m <- mean(rs)
  SM2[[i]] <- m
}

# 100 samples for Var3
SM3 <- vector(mode = "list", length = 100)
for(i in 1:100){
  s=srswor(250,length(Var3))
  rs <- as.vector(Var3[s==1])
  m <- mean(rs)
  SM3[[i]] <- m
}

# 100 samples for Var4
SM4 <- vector(mode = "list", length = 100)
for(i in 1:100){
  s=srswor(250,length(Var4))
  rs <- as.vector(Var4[s==1])
  m <- mean(rs)
  SM4[[i]] <- m
}

# Combine lists into a dataframe
df <- do.call(rbind, Map(data.frame, SM1=SM1, SM2=SM2, SM3=SM3, SM4=SM4))
PM1 <- mean(df$SM1)
PM2 <- mean(df$SM2)
PM3 <- mean(df$SM3)
PM4 <- mean(df$SM4)


# Plot the distributions
par(mfrow=c(2,2))
hist(df$SM1, main="Distribution of SM1", xlab=paste("Population Mean =", round(PM1,0),sep =""), col="orange")
hist(df$SM2, main="Distribution of SM2", xlab=paste("Population Mean =", round(PM2,0),sep =""), col="orange")
hist(df$SM3, main="Distribution of SM3", xlab=paste("Population Mean =", round(PM3,0),sep =""), col="orange")
hist(df$SM4, main="Distribution of SM4", xlab=paste("Population Mean =", round(PM4,0),sep =""), col="orange")

# Plot density function
par(mfrow=c(2,2))
plot(density(df$SM1), main="Distribution of SM1", xlab=paste("Population Mean =", round(PM1,0),sep =""))
polygon(density(df$SM1), col="orange", border="blue")
abline(v = PM1, col="red", lwd=2, lty=2)

plot(density(df$SM2), main="Distribution of SM2", xlab=paste("Population Mean =", round(PM2,0),sep =""))
polygon(density(df$SM2), col="orange", border="blue")
abline(v = PM2, col="red", lwd=2, lty=2)

plot(density(df$SM3), main="Distribution of SM3", xlab=paste("Population Mean =", round(PM3,0),sep =""))
polygon(density(df$SM3), col="orange", border="blue")
abline(v = PM3, col="red", lwd=2, lty=2)

plot(density(df$SM4), main="Distribution of SM4", xlab=paste("Population Mean =", round(PM4,0),sep =""))
polygon(density(df$SM4), col="orange", border="blue")
abline(v = PM4, col="red", lwd=2, lty=2)

# Confidence interval
v <- unlist(SM1) # convert the list to vectors
df1 <- do.call(rbind, Map(data.frame, SM1=v, sd=(v-PM1)^2)) # new dataframe
sum <- sum(df1$sd) # sum of column sd
sd <- sqrt(sum/99) # standard deviation

error <- qnorm(0.975)*sd/sqrt(100)
Lb <- PM1-error # Lowe bound
Ub <- PM1+error # Upper bound
Lb
Ub

# True population mean
TPM <- mean(Var1)
TPM

# References: https://stackoverflow.com/questions/11206378/inserting-function-variable-into-graph-title-in-r
# Reference: https://stackoverflow.com/questions/28630024/combine-two-lists-in-a-dataframe-in-r
# Reference: https://www.statmethods.net/graphs/density.html
