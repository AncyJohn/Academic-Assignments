require(readxl)
df <- read_excel('Ass2data.xlsx')

## Systematic sample of size 40
N <- nrow(df)
sys.sample <- function(N,n){
  k <- ceiling(N/n) #ceiling(x) rounds to the nearest integer that's larger than x. This means ceiling (2.1) = 3 
  r <- sample(1:k, 1)
  s <- seq(r, r + k*(n-1), k)
  #cat("The selected systematic sample is: \"", s, "\"\n") # Note: the last command "\"\n" prints the result in a new line
  return(s)
}
set.seed(0710)
n <- 40
sample <- sys.sample(N,n) 
sample1 <- as.data.frame(df[sample,]) 

# sample error
mean <- colMeans(sample1[1], na.rm = TRUE) # sample mean
mean[1]
variance <- var(sample1[1]) # variance of the sample
variance[,1]
mean_variance <- (variance[,1] / n) * (1-(n/N)) # variance of sample mean
mean_variance
se <- sqrt(mean_variance) # standard error
se
sample_error <- 1.96 * se # 95% confidence level
sample_error
LB <- mean - sample_error # Lower bound 
LB
UB<- mean + sample_error # Upper bound
UB

#Population Estimates
p_tot <- N*mean # estimated total
p_tot
p_var <- N^2 * mean_variance # Variance for the estimated total from sample
p_var
se <- sqrt(p_var) # standard error
se
p_error <- 1.96 * se # 95% confidence interval
p_error
LB <- p_tot - p_error
LB
UB <- p_tot + p_error
UB
# sum(df[1])

## Simple random sample without replacement
library(tidyverse)
df <- rename(df, 'land_size' = "Section sizes (Square Metres)")
attach(df)

library(sampling)
colnames(df)
set.seed(071)
s <- srswor(n,N)
sample2 <- as.vector(land_size[s==1])

# sample error
mean <- mean(sample2) # sample mean
mean
variance <- var(sample2) # variance of the sample
variance
mean_variance <- (variance / n) * (1-(n/N)) # variance of sample mean
mean_variance
se <- sqrt(mean_variance) # standard error
se
sample_error <- 1.96 * se # 95% confidence level
sample_error
LB <- mean - sample_error # Lower bound 
LB
UB<- mean + sample_error # Upper bound
UB

#Population Estimates
p_tot <- N*mean # estimated total
p_tot
p_var <- N^2 * mean_variance # Variance for the estimated total from sample
p_var
se <- sqrt(p_var) # standard error
se
p_error <- 1.96 * se # 95% confidence interval
p_error
LB <- p_tot - p_error
LB
UB <- p_tot + p_error
UB


