# Data Collection and Sampling Methods
These are the assignments done as part of the course curriculum.
Data collection process and the sampling methods are extemely important. Analytics on a wrong data is completely worthless.

Assignment1 is a discussion on framing appropriate questionnaire for the data collection and demonstration of simple random sampling using R package sampling. dataset: Ass1data

Assignment2 assess stratified sampling method & systematic sampling method with its descriptive statistics and a comparitative study with simple random sampling method. dataset: Ass2data

Assignment3 is an assessment of the random sampling survey design and adaptive cluster sampling process.

Final assessment checks on the important aspects of the survey process and the appropriate sampling methods.

Project: This is a group project. We were supposed to do the data collection manually. But we were not able to collect the data after the changed circumstances and complete lockdown. We went though all the stages of data collection survey. First we decided on survey goal and the objectives. On the next stage we designed the survey questionnnaire. We designed an app for the data collection project which is located at http://fbot.nz/covid-19/. We also considered the attire, bodylanguage and the script to be used when approaching the respondents, quality checking of the data and the final deliverables.
